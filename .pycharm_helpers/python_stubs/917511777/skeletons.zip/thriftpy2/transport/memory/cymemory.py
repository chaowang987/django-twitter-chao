# encoding: utf-8
# module thriftpy2.transport.memory.cymemory
# from /home/vagrant/.local/lib/python3.6/site-packages/thriftpy2/transport/memory/cymemory.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import thriftpy2.transport.cybase as __thriftpy2_transport_cybase


# functions

def __pyx_unpickle_TCyMemoryBuffer(*args, **kwargs): # real signature unknown
    pass

# classes

class TCyMemoryBuffer(__thriftpy2_transport_cybase.CyTransportBase):
    # no doc
    def clean(self, *args, **kwargs): # real signature unknown
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def getvalue(self, *args, **kwargs): # real signature unknown
        pass

    def is_open(self, *args, **kwargs): # real signature unknown
        pass

    def open(self, *args, **kwargs): # real signature unknown
        pass

    def read(self, *args, **kwargs): # real signature unknown
        pass

    def setvalue(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f9f8f7a6ed0>'


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9f8f2bf780>'

__spec__ = None # (!) real value is "ModuleSpec(name='thriftpy2.transport.memory.cymemory', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9f8f2bf780>, origin='/home/vagrant/.local/lib/python3.6/site-packages/thriftpy2/transport/memory/cymemory.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}

