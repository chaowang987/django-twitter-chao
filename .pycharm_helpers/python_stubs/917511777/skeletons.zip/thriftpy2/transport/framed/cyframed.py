# encoding: utf-8
# module thriftpy2.transport.framed.cyframed
# from /home/vagrant/.local/lib/python3.6/site-packages/thriftpy2/transport/framed/cyframed.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import thriftpy2.thrift as __thriftpy2_thrift
import thriftpy2.transport.cybase as __thriftpy2_transport_cybase


# functions

def __pyx_unpickle_TCyFramedTransport(*args, **kwargs): # real signature unknown
    pass

# classes

class TCyFramedTransport(__thriftpy2_transport_cybase.CyTransportBase):
    # no doc
    def clean(self, *args, **kwargs): # real signature unknown
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def is_open(self, *args, **kwargs): # real signature unknown
        pass

    def open(self, *args, **kwargs): # real signature unknown
        pass

    def read(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __pyx_vtable__ = None # (!) real value is '<capsule object NULL at 0x7f9f8f7a6d80>'


class TCyFramedTransportFactory(object):
    # no doc
    def get_transport(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'thriftpy2.transport.framed.cyframed', 'get_transport': <cyfunction TCyFramedTransportFactory.get_transport at 0x7f9f8f7e58e0>, '__dict__': <attribute '__dict__' of 'TCyFramedTransportFactory' objects>, '__weakref__': <attribute '__weakref__' of 'TCyFramedTransportFactory' objects>, '__doc__': None})"


class TTransportException(__thriftpy2_thrift.TException):
    """ Custom Transport Exception class """
    def __init__(self, type=0, message=None): # reliably restored by inspect
        # no doc
        pass

    ALREADY_OPEN = 2
    END_OF_FILE = 4
    NOT_OPEN = 1
    thrift_spec = {
        1: (
            11,
            'message',
        ),
        2: (
            8,
            'type',
        ),
    }
    TIMED_OUT = 3
    UNKNOWN = 0


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9f8f2bf1d0>'

__spec__ = None # (!) real value is "ModuleSpec(name='thriftpy2.transport.framed.cyframed', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9f8f2bf1d0>, origin='/home/vagrant/.local/lib/python3.6/site-packages/thriftpy2/transport/framed/cyframed.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}

