# encoding: utf-8
# module thriftpy2.protocol.cybin
# from /home/vagrant/.local/lib/python3.6/site-packages/thriftpy2/protocol/cybin.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import thriftpy2.thrift as __thriftpy2_thrift


# functions

def read_val(*args, **kwargs): # real signature unknown
    pass

def skip(*args, **kwargs): # real signature unknown
    pass

def write_val(*args, **kwargs): # real signature unknown
    pass

def __pyx_unpickle_TCyBinaryProtocol(*args, **kwargs): # real signature unknown
    pass

# classes

class ProtocolError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



class TCyBinaryProtocol(object):
    # no doc
    def read_message_begin(self, *args, **kwargs): # real signature unknown
        pass

    def read_message_end(self, *args, **kwargs): # real signature unknown
        pass

    def read_struct(self, *args, **kwargs): # real signature unknown
        pass

    def skip(self, *args, **kwargs): # real signature unknown
        pass

    def write_message_begin(self, *args, **kwargs): # real signature unknown
        pass

    def write_message_end(self, *args, **kwargs): # real signature unknown
        pass

    def write_struct(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    decode_response = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    strict_read = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    strict_write = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    trans = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class TCyBinaryProtocolFactory(object):
    # no doc
    def get_protocol(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __dict__ = None # (!) real value is "mappingproxy({'__module__': 'cybin', '__init__': <cyfunction TCyBinaryProtocolFactory.__init__ at 0x7f9f8f7e5a70>, 'get_protocol': <cyfunction TCyBinaryProtocolFactory.get_protocol at 0x7f9f8f7e5b38>, '__dict__': <attribute '__dict__' of 'TCyBinaryProtocolFactory' objects>, '__weakref__': <attribute '__weakref__' of 'TCyBinaryProtocolFactory' objects>, '__doc__': None})"


class TDecodeException(__thriftpy2_thrift.TException):
    # no doc
    def __init__(self, name, fid, field, value, ttype, spec=None): # reliably restored by inspect
        # no doc
        pass

    def __str__(self): # reliably restored by inspect
        # no doc
        pass


# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9f8f2c34e0>'

__spec__ = None # (!) real value is "ModuleSpec(name='thriftpy2.protocol.cybin', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f9f8f2c34e0>, origin='/home/vagrant/.local/lib/python3.6/site-packages/thriftpy2/protocol/cybin.cpython-36m-x86_64-linux-gnu.so')"

__test__ = {}

