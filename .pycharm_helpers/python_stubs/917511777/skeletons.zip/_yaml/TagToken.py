# encoding: utf-8
# module _yaml
# from /usr/lib/python3/dist-packages/_yaml.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc

# imports
import builtins as __builtins__ # <module 'builtins' (built-in)>
import yaml as yaml # /usr/lib/python3/dist-packages/yaml/__init__.py
import yaml.error as __yaml_error
import yaml.events as __yaml_events
import yaml.nodes as __yaml_nodes
import yaml.tokens as __yaml_tokens


class TagToken(__yaml_tokens.Token):
    # no doc
    def __init__(self, value, start_mark, end_mark): # reliably restored by inspect
        # no doc
        pass

    id = '<tag>'


