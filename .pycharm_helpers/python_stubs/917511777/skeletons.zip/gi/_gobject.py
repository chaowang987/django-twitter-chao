# encoding: utf-8
# module gi._gobject
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# no classes
# variables with complex values

pygobject_version = (
    3,
    26,
    1,
)

_PyGObject_API = None # (!) real value is '<capsule object "gobject._PyGObject_API" at 0x7f09f34103f0>'

