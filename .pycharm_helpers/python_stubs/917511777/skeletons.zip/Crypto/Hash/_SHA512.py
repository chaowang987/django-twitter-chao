# encoding: utf-8
# module Crypto.Hash._SHA512
# from /usr/lib/python3/dist-packages/Crypto/Hash/_SHA512.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

block_size = 128

digest_size = 64

# functions

def new(string=None): # real signature unknown; restored from __doc__
    """ new([string]): Return a new _SHA512 hashing object.  An optional string argument may be provided; if present, this string will be automatically hashed into the initial state of the object. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412d30>'

__spec__ = None # (!) real value is "ModuleSpec(name='Crypto.Hash._SHA512', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412d30>, origin='/usr/lib/python3/dist-packages/Crypto/Hash/_SHA512.cpython-36m-x86_64-linux-gnu.so')"

