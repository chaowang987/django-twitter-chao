# encoding: utf-8
# module Crypto.Cipher._CAST
# from /usr/lib/python3/dist-packages/Crypto/Cipher/_CAST.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

block_size = 8

key_size = 0

MODE_CBC = 2
MODE_CFB = 3
MODE_CTR = 6
MODE_ECB = 1
MODE_OFB = 5
MODE_PGP = 4

# functions

def new(key, mode=None, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ new(key, [mode], [IV]): Return a new _CAST encryption object. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412e10>'

__spec__ = None # (!) real value is "ModuleSpec(name='Crypto.Cipher._CAST', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412e10>, origin='/usr/lib/python3/dist-packages/Crypto/Cipher/_CAST.cpython-36m-x86_64-linux-gnu.so')"

