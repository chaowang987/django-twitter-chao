# encoding: utf-8
# module Crypto.Util._counter
# from /usr/lib/python3/dist-packages/Crypto/Util/_counter.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def _newBE(*args, **kwargs): # real signature unknown
    pass

def _newLE(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412be0>'

__spec__ = None # (!) real value is "ModuleSpec(name='Crypto.Util._counter', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412be0>, origin='/usr/lib/python3/dist-packages/Crypto/Util/_counter.cpython-36m-x86_64-linux-gnu.so')"

