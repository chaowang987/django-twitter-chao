# encoding: utf-8
# module Crypto.Util.strxor
# from /usr/lib/python3/dist-packages/Crypto/Util/strxor.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def strxor(a, b): # real signature unknown; restored from __doc__
    """
    strxor(a:str, b:str) -> str
    
    Return a XOR b.  Both a and b must have the same length.
    """
    return ""

def strxor_c(s, c): # real signature unknown; restored from __doc__
    """
    strxor_c(s:str, c:int) -> str
    
    Return s XOR chr(c).  c must be in range(256).
    """
    return ""

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412ba8>'

__spec__ = None # (!) real value is "ModuleSpec(name='Crypto.Util.strxor', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f3412ba8>, origin='/usr/lib/python3/dist-packages/Crypto/Util/strxor.cpython-36m-x86_64-linux-gnu.so')"

