# encoding: utf-8
# module _curses_panel
# from /usr/lib/python3.6/lib-dynload/_curses_panel.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

version = '2.1'

__version__ = '2.1'

# functions

def bottom_panel(*args, **kwargs): # real signature unknown
    pass

def new_panel(*args, **kwargs): # real signature unknown
    pass

def top_panel(*args, **kwargs): # real signature unknown
    pass

def update_panels(*args, **kwargs): # real signature unknown
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f34fab00>'

__spec__ = None # (!) real value is "ModuleSpec(name='_curses_panel', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f34fab00>, origin='/usr/lib/python3.6/lib-dynload/_curses_panel.cpython-36m-x86_64-linux-gnu.so')"

