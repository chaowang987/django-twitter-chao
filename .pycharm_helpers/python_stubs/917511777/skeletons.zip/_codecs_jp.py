# encoding: utf-8
# module _codecs_jp
# from /usr/lib/python3.6/lib-dynload/_codecs_jp.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f34fab00>'

__map_cp932ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f3410030>'

__map_jisx0208 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc180>'

__map_jisx0212 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc150>'

__map_jisx0213_1_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc2a0>'

__map_jisx0213_1_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23ccde0>'

__map_jisx0213_2_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23ccc00>'

__map_jisx0213_2_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cce10>'

__map_jisx0213_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23ccd50>'

__map_jisx0213_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cce70>'

__map_jisx0213_pair = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cce40>'

__map_jisxcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc270>'

__spec__ = None # (!) real value is "ModuleSpec(name='_codecs_jp', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f34fab00>, origin='/usr/lib/python3.6/lib-dynload/_codecs_jp.cpython-36m-x86_64-linux-gnu.so')"

