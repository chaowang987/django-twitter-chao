# encoding: utf-8
# module cython_runtime
# from /usr/lib/python3/dist-packages/twisted/test/raiser.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# no classes
