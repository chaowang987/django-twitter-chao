# encoding: utf-8
# module cython_runtime
# from /home/vagrant/.local/lib/python3.6/site-packages/thriftpy2/transport/memory/cymemory.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

__loader__ = None

__spec__ = None

# no functions
# no classes
