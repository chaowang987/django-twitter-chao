# encoding: utf-8
# module _codecs_cn
# from /usr/lib/python3.6/lib-dynload/_codecs_cn.cpython-36m-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f34fab00>'

__map_gb18030ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc2a0>'

__map_gb2312 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc180>'

__map_gbcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc270>'

__map_gbkext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f09f23cc150>'

__spec__ = None # (!) real value is "ModuleSpec(name='_codecs_cn', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f09f34fab00>, origin='/usr/lib/python3.6/lib-dynload/_codecs_cn.cpython-36m-x86_64-linux-gnu.so')"

